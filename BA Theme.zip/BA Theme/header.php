<!DOCTYPE html>
 <html>
  <head>
    <meta charset="utf-8">
    <title>Brandon Aaronson, Front-End Developer</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>